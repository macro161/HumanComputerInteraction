function validateDate(){
  var dateValue = document.getElementById("date").value;

  if(!(/^\d{4}\-\d{1,2}\-\d{1,2}$/.test(dateValue))){
    alert("Neteisingai įvesta data.");
    return false;
  }
    var parts = dateValue.split("-");
    var day = parseInt(parts[2]);
    var month = parseInt(parts[1]);
    var year = parseInt(parts[0]);

  if (month < 1 || month > 12) {
        alert("Neteisingai įvestas mėnesis.");
        return false;
    }

    if (day < 1 || day > 31) {
        alert("Neteisingai įvesta diena.");
        return false;
    }

    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        alert("Neteisingai įvesta mėnesio diena.");
        return false;
    }
    return true;
}

function validateEmpty() {
    var nameValue = document.getElementById("vardas").value;
    var lastNameValue = document.getElementById("pavarde").value;
    var emailValue = document.getElementById("pastas").value;
    var numberValue = document.getElementById("numeris").value;

    if ((nameValue.length > 0) && (lastNameValue.length > 0) && (emailValue.length > 0) && (numberValue.length > 0)) {
        return true;
    } else {
        return false;
    }
}

function validateNumber(){
    var regNrValue = document.getElementById("regnr").value;

    if (isNaN(regNrValue) || regNrValue == 0 || regNrValue < 0) {
        alert("Registracijos numeris neteisingas.");
        return false;
    }
    return true;
}

function validate(){
  if(validateDate()==true && validateEmpty()==true && validateNumber()==true)
      return true;

  else return false;
}


function showTable() {
    if (validate() == true) {

        var value = $(".lent").serializeArray();
        var data = JSON.stringify(value);
          alert("gerai");
        console.log(data);
        $.ajax({
            url: "https://api.myjson.com/bins",
            type: "POST",
            data: data,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            error: alert("nepavyko"),
            success: function (data, textStatus, jqXHR) {
                $.get(data.uri, function (data, textStatus, jqXHR) {

                    //var json = JSON.stringify(data);
                    alert("gerai2");
                    //$("#data").val(json);
                    $("#jsonDate").html(data[0].value);
                    $("#jsonName").html(data[1].value);
                    $("#jsonLastName").html(data[2].value);
                    $("#jsonEmail").html(data[3].value);
                    $("#jsonNr").html(data[4].value);
                    $("#jsonRegNr").html(data[5].value);
                  });
                  }
        });
    }
}
